<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 for-comment">
	<h3>Comment</h3>
	<hr/>
	<div id="comment-list">
		<div class="post-item" style="margin-top: 15px;">
			<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 nopadding">
				<img class="img-circle post-img" src="<?=base_url()?>uploadfiles/member-images/profil.jpg">
			</div>
			<div class="col-lg-11 col-md-11 col-sm-11 col-xs-11 nopadding">
				<h4>Aldena Oktavian P.</h4>
				<hr/>
				<p>
					comment disinii yaaa :D :D
				</p>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="write-comment">
		<textarea class="form-control" name="new_post" id="new_post" placeholder="Write a comment . . ."></textarea>
	</div>
</div>
<button title="Close (Esc)" type="button" class="mfp-close">×</button>