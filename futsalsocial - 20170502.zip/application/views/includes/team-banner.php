    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopadding">
                <div class="profile-image">
                    <img class="img-circle" src="<?=base_url()?>uploadfiles/member-images/profil.jpg">
                    <h5 class="hidden-sm hidden-xs">Team Coba</h5>
                    <h6 class="hidden-lg hidden-md">Team Coba</h6>
                </div>
            	<img src="<?=base_url()?>uploadfiles/team-banner/banner1.png" width="100%">
            </div>
        </div>
    </div>