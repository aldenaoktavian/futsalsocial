<div class="navbar-left navbar-header" style="background-color: white;">
	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
	    <span class="sr-only">Toggle navigation</span>
	    <span class="icon-bar"></span>
	    <span class="icon-bar"></span>
	    <span class="icon-bar"></span>
	</button>
</div>
<div class="navbar-left" style="float: right !important;">
	<div class="navbar-default sidebar" role="navigation">
        <div class="sidebar-nav navbar-collapse collapse">
	        <ul class="nav" id="side-menu">
	            <li>
	                <a href="<?=base_url()?>social/timeline" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Timeline</span> </a>
	            </li>
				<li>
	                <a href="<?=base_url()?>team/challengelist" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Team</span> </a>
	            </li>
	            <li>
	                <a href="<?=base_url()?>team/profile" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">My Team</span> </a>
	            </li>
	            <li>
	                <a href="<?=base_url()?>challenge/pilihtim" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Challenge</span> </a>
	            </li>
	            <li>
	                <a href="layout.html" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Booking</span> </a>
	            </li>
	        </ul>
    	</div>
	</div>
</div>