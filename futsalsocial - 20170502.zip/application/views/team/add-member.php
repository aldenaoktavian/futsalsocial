<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 for-comment">
	<h3>Tambah Anggota</h3>
	<hr/>
	<form action="<?=base_url()?>team/save_edit_desc">
		<br/>
		<input class="form-control" type="text" name="search_team" id="search_team" value="" placeholder="Cari . . ." /><br/>

		<!-- start list member terdaftar -->
		<div class="bg-post member-item">
			<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
				<img class="img-circle hidden-xs" src="<?=base_url()?>uploadfiles/member-images/profil.jpg">
				<span>Aldena Oktavian</span>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
				<button type="submit" class="btn btn-primary">Tambah</button>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="bg-post member-item">
			<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
				<img class="img-circle hidden-xs" src="<?=base_url()?>uploadfiles/member-images/profil.jpg">
				<span>Aldena Oktavian</span>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
				<button type="submit" class="btn btn-primary">Tambah</button>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="bg-post member-item">
			<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
				<img class="img-circle hidden-xs" src="<?=base_url()?>uploadfiles/member-images/profil.jpg">
				<span>Aldena Oktavian</span>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
				<button type="submit" class="btn btn-primary">Tambah</button>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="bg-post member-item">
			<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
				<img class="img-circle hidden-xs" src="<?=base_url()?>uploadfiles/member-images/profil.jpg">
				<span>Aldena Oktavian</span>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
				<button type="submit" class="btn btn-primary">Tambah</button>
			</div>
			<div class="clearfix"> </div>
		</div>
		<!-- end list member terdaftar -->

		<!--Deskripsi Team
		<textarea class="form-control" name="team_desc" id="team_desc" style="height: 200px;resize: none;"></textarea><br/>
		<button type="submit" class="btn btn-primary" style="float: right;">Update</button>-->
		<div class="clearfix"> </div>
	</form>
</div>
<button title="Close (Esc)" type="button" class="mfp-close">×</button>